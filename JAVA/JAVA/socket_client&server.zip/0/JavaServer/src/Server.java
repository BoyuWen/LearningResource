import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	public static void main(String[] args) {
		ServerSocket server;
		try {
			server = new ServerSocket(8888);
			// 接收客户端连接
			System.out.println("server listener:");
			Socket client = server.accept();

			// 获得客户端请求
			InputStream is;
			try {
				is = client.getInputStream();
				byte[] b = new byte[1024];
				is.read(b);
				String request = new String(b);
				System.out.println("Server received:" + request);

				// 向客户端发送响应
				OutputStream os = client.getOutputStream();
				String response;
				Scanner s = new Scanner(System.in);
				response = s.nextLine();
				os.write((response).getBytes());

				// 关闭网络连接
				is.close();
				os.close();
				client.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}