import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public static void main(String[] args) {
		Socket client;
		try {
			client = new Socket("127.0.0.1", 8888);
			// 获得网络输入/输出流
			InputStream is = client.getInputStream(); // 获得网络输入流
			OutputStream os = client.getOutputStream(); // 获得网络输出流

			// 发送数据到server
			byte[] input = new byte[1024];
			System.in.read(input);
			os.write(input);
			os.flush();// 刷新请求

			// 接收响应
			byte[] b = new byte[1024];
			StringBuffer strb = new StringBuffer();
			while (is.read(b) != -1) {
				strb.append(new String(b));
			}
			System.out.println(strb.toString());
			
			
			// 关闭连接
			is.close();
			os.close();
			client.close();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}