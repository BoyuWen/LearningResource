import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;


public class RespouseRunnable implements Runnable {

	private Socket client;
	
	public RespouseRunnable(Socket client) {
		super();
		this.client = client;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		// 获得客户端请求
		InputStream is;
		try {
			is = client.getInputStream();
			byte[] b = new byte[1024];
			is.read(b);
			String request = new String(b);
			System.out.println("Server received:" + request);
			
			// 向客户端发送响应
			OutputStream os = client.getOutputStream();
			os.write(("this is server return string !").getBytes());
			
			// 关闭网络连接
			is.close();
			os.close();
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
