import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) {
		ServerSocket server;
		try {
			server = new ServerSocket(8888);
			// 接收客户端连接
			System.out.println("server listener:");
			while (true) {
				Socket client = server.accept();
				
				new Thread(new RespouseRunnable(client)).start();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}