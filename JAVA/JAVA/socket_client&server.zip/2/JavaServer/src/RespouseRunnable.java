import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class RespouseRunnable implements Runnable {

	private Socket client;

	public RespouseRunnable(Socket client) {
		super();
		this.client = client;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		// 获得客户端请求
		try {
			// 获得网络输入/输出流
			new Thread(new ReadMsgRunnable(client)).start();

			OutputStream os = client.getOutputStream(); // 获得网络输出流

			while (true) {
				// 发送数据到server
				byte[] input = new byte[1024];
				System.in.read(input);
				os.write(input);
				os.flush();// 刷新请求
				String inputstr = new String(input);
				if (inputstr.startsWith("end")) {
					break;
				}
			}

			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				client.close();
				System.exit(0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
