import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public static void main(String[] args) {
		Socket client = null;
		try {
			client = new Socket("127.0.0.1", 8888);
			// 获得网络输入/输出流
			new Thread(new ReadMsgRunnable(client)).start();
			
			OutputStream os = client.getOutputStream(); // 获得网络输出流

			while(true){
				// 发送数据到server
				byte[] input = new byte[1024];
				System.in.read(input);
				os.write(input);
				os.flush();// 刷新请求
				String inputstr = new String(input);
				if (inputstr.startsWith("end")) {
					break;
				}
			}
			
			os.close();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				client.close();
				System.exit(0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}