import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.Buffer;

public class ReadMsgRunnable implements Runnable {
	private Socket client;
	private BufferedReader bufr;
	
	public ReadMsgRunnable(Socket client) {
		super();
		this.client = client;
		try {
			bufr = new BufferedReader(new InputStreamReader(client.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			// 接收响应
			String temp = null;

			while (true) {
				temp = bufr.readLine();
				System.out.println(temp.trim());
				if (temp.startsWith("end")) {
					break;
				}
			}

			bufr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				client.close();
				System.exit(0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
