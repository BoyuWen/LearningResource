package com.dev;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Administrator
 * 
 */
public class TestDbPool {

	/**
	 * @param args
	 */
public static void main(String[] args) {
	SimpleDateSource databasePool = SimpleDateSource.instance();
	
	try {
		Connection connection = databasePool.getConnection();
		Statement stat = connection.createStatement();
		String sql = "select * from t1";
		ResultSet rs = stat.executeQuery(sql);
		while (rs.next()) {
			System.out.println(rs.getInt("id") + "  " + rs.getString("name"));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
		// 闇�瑕佸叧闂暟鎹簱杩炴帴锛岄噴鏀捐祫婧�
	}
}

}

