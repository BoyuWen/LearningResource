package com.dev;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.impl.DefaultConnectionTester;


public final class ConnectionManager {
	 private ComboPooledDataSource ds;
	 private ConnectionManager connManger;
	 private ConnectionManager() throws PropertyVetoException{
	  ds = new ComboPooledDataSource();
	  //设置c3p0连接池的数据库驱动类
	  ds.setDriverClass("com.mysql.jdbc.Driver");
	  //设置c3p0连接池数据库连接URL
	  ds.setJdbcUrl("jdbc:mysql://127.0.0.1:3306/mydb");
	  //设置c3p0连接池数据库用户名
	  ds.setUser("root");
	  //设置c3p0连接池数据库密码
	  ds.setPassword("");
	  //当连接池中的连接用完时，C3P0一次性创建新连接的数目2
	  ds.setAcquireIncrement(2);
	  //连接关闭时默认将所有未提交的操作回滚。默认为false；
	  ds.setAutoCommitOnClose(false);
	
	  ds.setConnectionTesterClassName(new DefaultConnectionTester().getClass().getName());
	  //hook方法，在对相关资源做操作的时候，''他所操作的connection是真实的数据库连接，而不是proxy过的connection''
	 // ds.setConnectionCustomizerClassName("");
	  //连接池数据源
	  //ds.setConnectionPoolDataSource(ConnectionPoolDataSource 对象);
	  //idleConnectionTestPeriod：隔多少秒检查所有连接池中的空闲连接，默认为0表示不检查
	  ds.setIdleConnectionTestPeriod(10);
	  //初始化时创建的连接数，应在minPoolSize与maxPoolSize之间取值。默认为3；
	  ds.setInitialPoolSize(5);
	  //最大空闲时间，超过空闲时间的连接将被丢弃。为0或负数则永不丢弃。默认为0；
	  ds.setMaxIdleTime(3);
	  //连接池中保留的最大连接数。默认为15；
	  ds.setMaxPoolSize(100);
	  /**
	   * JDBC的标准参数，用以控制数据源内加载的PreparedStatement数量。
	   * 但由于预缓存的Statement属 于单个Connection而不是整个连接池。
	   * 所以设置这个参数需要考虑到多方面的因素，如果maxStatements与 maxStatementsPerConnection均为0，
	   * 则缓存被关闭。默认为0；
	   */
	  ds.setMaxStatements(1000);
	  //连接池内单个连接所拥有的最大缓存Statement数。默认为0；
	  ds.setMaxStatements(100);
	  //C3P0是异步操作的，缓慢的JDBC操作通过帮助进程完成。扩展这些操作可以有效的提升性能，通过多线程实现多个操作同时被执行。默认为3；
	  ds.setNumHelperThreads(5);
	 }
	 
	 public static void main(String[] args) {
		  try {
			   ConnectionManager connManger = new ConnectionManager();
			   Connection conn =  connManger.ds.getConnection();
			   Statement st = conn.createStatement();
			   String sql = "select * from t1";
			   ResultSet rs = st.executeQuery(sql);
			   while(rs.next()){
			    System.out.println(rs.getInt("id") + "," + rs.getString("name"));
			    }
			  }  catch (PropertyVetoException e) {
			   e.printStackTrace();
			  } catch (SQLException e) {
			   e.printStackTrace();
			   }
	}
}