CREATE DATABASE `em`
    CHARACTER SET 'utf8'
    COLLATE 'utf8_general_ci';